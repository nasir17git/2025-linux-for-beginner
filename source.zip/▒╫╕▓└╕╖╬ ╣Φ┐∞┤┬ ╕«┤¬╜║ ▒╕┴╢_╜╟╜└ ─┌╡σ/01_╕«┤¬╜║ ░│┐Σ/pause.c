#include <unistd.h>

int main(void) {
	pause();
	return 0;
}
