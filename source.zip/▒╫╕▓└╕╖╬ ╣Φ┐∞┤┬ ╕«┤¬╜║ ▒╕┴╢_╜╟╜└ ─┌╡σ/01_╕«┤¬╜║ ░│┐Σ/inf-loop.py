#!/usr/bin/python3

while True:
    pass
