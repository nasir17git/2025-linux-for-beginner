#!/usr/bin/python3

import os

while True:
    os.getppid()
