#!/bin/bash

TMP=$(cat count)
echo $((TMP + 1)) >count
