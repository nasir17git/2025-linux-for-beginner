#!/bin/bash

flock lock ./inc.sh
