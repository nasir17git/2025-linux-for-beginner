#!/usr/bin/python3

# 부하 정도를 조절하는 값.
# time 명령어를 사용해서 실행했을 때 몇 초 정도에 끝나도록 조절하면 결과를 확인하기 좋음
NLOOP=100000000

for _ in range(NLOOP):
    pass
