#include <stdlib.h>

int main(void) {
	int *p = NULL;
	*p = 0;
}
